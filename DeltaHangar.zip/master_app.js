(function(){
  var app = angular.module("DeltaHangar", []);
  var AccountNumber;
    app.controller("ProjectDetailsCtrl", ProjectDetailsCtrl);
	app.controller("ClickToGetValue", ClickToGetValue);
	app.value("headerNameSvc", "hai");

    function ProjectDetailsCtrl() {
        
      this.projectDetailsData = projectsMaster;

		 this.SelectedContact = this.projectDetailsData[0];
		 
		this.SelectContact = function (index) {
				this.SelectedContact = this.projectDetailsData[index];
      }

    }
	
	$(window).resize(function() {
	if($(window).width() < 768 ) {
			$('.imagesize').attr('src','images/mobile/see_yourself_banner_mobile.jpg');
			
	}
	if($(window).width() > 768 ) {
			$('.imagesize').attr('src','images/see_yourself_banner_desktop.jpg');
			
	}
});
	
   function ClickToGetValue(headerNameSvc) {
      this.appTitle = headerNameSvc;
    }
	
	
	
	var projectsMaster = [
   {
      "projects":{
         "id":"1",
         "title":"What can we do for faster boarding?",
         "description":"The Hangar sponsored several projects at the Georgia Institute of Technology's third-annual Hackathon. From real-time seating sensors to a tracker that monitors overhead bin usage, these innovative ideas help delta take off to better boarding.",
         "pagelink":"projects-details.html"
      },
      "picture":{
         "large":"images/project_img1.jpg"
      },
      "homepagepicture":{
         "large":"images/slider/slide1.jpg"
      }
   },
   {
      "projects":{
         "id":"2",
         "title":"Can Customers check flight status with voice?",
         "description":"We're here to help - even through voice assistants like Alexa, Siri and Cortana. Through Delta, The Hangar's working on better ways to use voice to assit travelers at home and during busy travel days.",
         "pagelink":"projects-details.html"
      },
      "picture":{
         "large":"images/project_img2.jpg"
       },
      "homepagepicture":{
         "large":"images/slider/slide2.jpg"
      }
   },
   {
      "projects":{
         "id":"3",
         "title":"How can we make airplane galley storage better?",
         "description":"In a tight galley on a crowded plane, every inch matters. The Hangar rethought how to make the most of these spaces - finding design-driven solutions that saves Flight Attendents needed time.",
         "pagelink":"projects-details.html"
      },
      "picture":{
         "large":"images/project_img3.jpg"
       },
      "homepagepicture":{
         "large":"images/slider/slide3.jpg"
      }
   },
   {
      "projects":{
         "id":"4",
         "title":"Can we build a better airline industry?",
         "description":"Each day, innovators come together at The Hangar to rethink, re-engineer and tackle some of the airline industry’s toughest problems — with support from Delta Air Lines.",
         "pagelink":"projects-details.html"
      },
      "picture":{
         "large":"images/see_yourself_banner_desktop.jpg"
       },
      "homepagepicture":{
         "large":"images/slider/slide4.jpg"
      }
   }
 ];
	

 })();   
