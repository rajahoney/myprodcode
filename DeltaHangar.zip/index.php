<?php 
/* Short and sweet */
define('WP_USE_THEMES', false);
require('./wp-blog-header.php');
?>
<!DOCTYPE html>
<html lang="en" ng-app="DeltaHangar">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<title>Delta The Hangar | Home</title>
	<meta name="keywords" content="Delta Air Lines, Innovation, Delta Innovation Center, Delta Innovation, The Hanger, Delta Global Innovation Center, Delta Innovation Lab, Delta Innovation Studio, Innovation Lab, Innovation Studio, Delta Georgia Tech, Delta Tech Square, Delta Georgia Institute of Technology, Delta Midtown, Delta Atlanta Midtown, Delta Atlanta, Delta Georgia">
	<meta name="description" content="We bring cutting-edge thinkers from aviation, engineering and technology together to form the global innovation center of Delta Air Lines. As a team, we aim to establish an enterprise-wide practice of human-centered design — improving employee fulfillment and customer satisfaction, solving real industry problems and shaping the future of aviation.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1, maximum-scale=1, user-scalable=yes">
	<link rel="shortcut icon" href="icons/Delta_favicon128.ico">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="fonts/stylesheet.css">
	<link rel="stylesheet" href="fonts/sourcecode/stylesheet_2.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
</head>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
<section class="navbar navbar-fixed-top custom-navbar" role="navigation">
	<div class="container headerContainer">
		<div class="navbar-header">
			<button class="navbar-toggle toggle-overlay" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="index.html" ><img src="images/logo.png" class="logosize" alt="slider image 1"></a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="about.html" class="smoothScroll">ABOUT</a></li>
				<li><a href="projects.html" class="smoothScroll">PROJECT</a></li>
				<li><a href="apply.html" class="smoothScroll">APPLY</a></li>
			</ul>
		</div>
		<aside>
		<a href="index.html" ><img src="images/logo.png" class="logosize1" alt="slider image 1"></a>
		<div class="navbar-header">
			 <div class="outer-close toggle-overlay">
				<a class="close"><span>&#10060</span></a>
			</div>
		</div>
  <nav>
    <ul class="navpadalign">
    <li><a href="about.html" class="smoothScroll">ABOUT</a></li>
	<li><a href="projects.html" class="smoothScroll">PROJECT</a></li>
	<li><a href="apply.html" class="smoothScroll">APPLY</a></li>
    </ul>
  </nav>
</aside>
	</div>
</section>

<div id="home" ng-controller="ProjectDetailsCtrl as pdData">
	<div class="site-slider">
        <ul class="bxslider">
			<li ng-repeat="projectDatas in pdData.projectDetailsData">
                <img src="{{projectDatas.Homepagepicture.large}}" alt="slider image 1" class="img-responsive bannerimgoveraide">
				<input type="hidden" name="idvalues" value="{{projectDatas.projects.id}}" ng-model='text'/>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="slider-caption">
                                <h2><span id="textdecorator">&nbsp;{{projectDatas.projects.title}}<span class="blinking-cursor">|</span></span></h2>
                                <p class="color-white">{{projectDatas.projects.description}}</p>
								<p class="color-white bodercolor"><a href='{{projectDatas.projects.pagelink}}?id={{projectDatas.projects.id}}' ng-click="pdData.SelectContact($index)" class="bodercolor">See project details</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
        </ul> 
    </div> 
</div>

<section id="portfolio" class="parallax-section">
	<div class="container">
		<div class="row">

			
			<div class="col-md-offset-2 col-md-8 col-sm-offset-2 colum8width">
					<h2 class="heading">At Delta Hangar, We’re Working To</h2>
			</div>

            <div class="col-md-4 col-sm-6">
				<div class="grid">
              		<figure class="effect-zoe">
						<img src="images/portfolio-img1.png" alt="portfolio img"/>		
					</figure>
					
					
					
				</div>
				<div class="imageTitle"> <p class="threeiconportion">Innovate the Airline<br/>
				Experience</p></div>
            </div>   
            <div class="col-md-4 col-sm-6">
				<div class="grid">
              		<figure class="effect-zoe">
						<img src="images/portfolio-img2.png" alt="portfolio img"/>			
					</figure>
				</div>
				<div class="imageTitle"> <p class="threeiconportion">Implement Design-Driven<br/>
				Thinking</p></div>
            </div> 
            <div class="col-md-4 col-sm-6">
				<div class="grid">
              		<figure class="effect-zoe">
						<img src="images/portfolio-img3.png" alt="portfolio img"/>		
					</figure>
				</div>
				<div class="imageTitle"> <p class="threeiconportion">Collaborate to<br/>
				Create Solutions </p></div>
            </div>         
        
            <div class="col-md-offset-2 col-md-8 col-sm-12">
            	<div class="portfolio-bottom">   		
					<p class="blackLink threeiconportion bodercolor"><a href="about.html" class="blackLink threeiconportion bodercolor">Get to know us</a></p>
            	</div>
            </div>    
		</div>
	</div>
</section>	


<section id="portfolio" class="parallax-section">
                <img src="images/see_yourself_banner_desktop.jpg" alt="slider image 4" class="imageminwidth imagesize">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="slider-caption belowspace">
                               <div class=" capitalHeading">
					<h1 class="heading color-white">See Yourself at Delta Hangar?  </h1>
					<br>
					<br>
					
					<p class="homelink">We’re always seeking innovative problem solvers, subject-matter experts and thinkers <br/>of all backgrounds to join our growing team.</p>	
					<br>
					<p class="color-white bodercolor"> <a href="https://delta.greatjob.net/jobs/JobListingAction.action?jobCategory=&PSUID=2d292c08-fc21-4e41-a478-52b3aa6ba897" target="_blank" class="whiteLink bodercolor">Apply Now »</a></p>
				</div>
                            </div>
                        </div>
                    </div>
                </div>
           
</section>

<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">	
			<div class="col-md-4 col-sm-6">	
			<div class="">
						<a href="index.html" ><img src="images/footer_logo.png" alt="footer img"/>		</a>	
			</div>
            </div>   
			<div class="col-sm-8">
				<div class="imageTitleLoc"> 
						<ul id="menu">
							<li><span class="footerlinks"><a class="footerlinks" target="_blank" href="http://www.delta.com/">Delta.com</a></span></li>
							<li><span class="footerlinks"><a class="footerlinks" target="_blank" href="http://news.delta.com/">News Hub</a></span></li>
							<li><span class="footerlinks"><a class="footerlinks" target="_blank" href="http://www.delta.com/content/www/en_US/legal.html">Legal</a></span></li>
							<li><span class="footerlinks">  <a class="footerlinks" href="mailto:innovation@delta.com?Subject=Delta The Hangar - Contact Us">Contact Us </a></span></li>
</ul>
					
				</div>
            </div>
           
			</div>
		</div>
	</div>
	<div class="copyrighttext">Copyright ©2017 Delta Air Lines, Inc. All right reserved</div>
</footer>
<!-- Javascript -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.parallax.js"></script>
<script src="js/custom.js"></script>
<script src="master_app.js"></script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-99286712-1', 'auto');
  ga('send', 'pageview');
</script>
</body>
</html>