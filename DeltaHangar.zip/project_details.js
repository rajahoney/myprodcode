var app2 = angular.module('app2', [], function($locationProvider) {
      $locationProvider.html5Mode(true);
    });
	

app2.controller('QueryCntl',['$scope','$location','$http', function($scope, $location, $http) {
	  $scope.projectsData = [];
      $scope.target = $location.search()['id'];
	  $scope.projectsData = GetProjectDetails(parseInt($scope.target));
}]);



function GetProjectDetails(index) {

		this.projectDetailsData = projectDetails;
		var count = Object.keys(this.projectDetailsData).length - 1;
		var num = index - 1;
		if(num >= count){
			return this.projectDetailsData[count];
		}else if (num < 0){
			return this.projectDetailsData[0];
		}else{
			return this.projectDetailsData[num];
		}

    }
	
	
	
var projectDetails = [
   {
      "projects":{
         "id":1,
         "title":"What can we do for faster boarding?",
         "tagdetails":"improve air travel by empowering Delta employees with technology",
         "description":"The Hangar sponsored several projects at the Georgia Institute of Technology's third-annual Hackathon. From real-time seating sensors to a tracker that monitors overhead bin usage, these innovative ideas help delta take off to better boarding.",
         "pagelink":"https://news.delta.com/georgia-tech-hackathon-sky-s-limit-air-travel-innovation",
         "participants":"1100",
         "teams":"80",
         "winners":"4",
         "results":"Delta Innovation leaders selected their favorite ideas. Chow's team won grand prize in the Air Travel category. Other winners and their projects are listed below."
      },
      "picture":{
         "large":"images/project_hero_desktop_1600.jpg"
      },
	  "prenextpagelink":{
         "pages":"projects-details.html"
      },
	  "projectimages":{
         "pic1":"images/project1.jpg",
		 "pic2":"images/project2.jpg",
		 "pic3":"images/project3.jpg"
      }
   },
   {
      "projects":{
         "id":2,
         "title":"Can Customers check flight status with voice?",
         "tagdetails":"improve air travel by empowering Delta employees with technology",
         "description":"We're here to help - even through voice assistants like Alexa, Siri and Cortana. Through Delta, The Hangar's working on better ways to use voice to assit travelers at home and during busy travel days.",
         "pagelink":"https://news.delta.com/georgia-tech-hackathon-sky-s-limit-air-travel-innovation",
         "participants":"100",
         "teams":"20",
         "winners":"3",
         "results":"Delta Innovation leaders selected their favorite ideas. Raja's team won grand prize in the Air Travel category. Other winners and their projects are listed below."
      },
      "picture":{
         "large":"images/project_img2.jpg"
      },
	  "prenextpagelink":{
         "pages":"projects-details.html"
      },
	  "projectimages":{
         "pic1":"images/project1.jpg",
		 "pic2":"images/project2.jpg",
		 "pic3":"images/project3.jpg"
      }
   },
   {
      "projects":{
         "id":3,
         "title":"How can we make airplane galley storage better?",
         "tagdetails":"improve air travel by empowering Delta employees with technology",
         "description":"In a tight galley on a crowded plane, every inch matters. The Hangar rethought how to make the most of these spaces - finding design-driven solutions that saves Flight Attendents needed time.",
         "pagelink":"https://news.delta.com/georgia-tech-hackathon-sky-s-limit-air-travel-innovation",
         "participants":"1300",
         "teams":"60",
         "winners":"10",
         "results":"Delta Innovation leaders selected their favorite ideas. Antony's team won grand prize in the Air Travel category. Other winners and their projects are listed below."
      },
      "picture":{
         "large":"images/project_img3.jpg"
      },
	  "prenextpagelink":{
         "pages":"projects-details.html"
      },
	  "projectimages":{
         "pic1":"images/project1.jpg",
		 "pic2":"images/project2.jpg",
		 "pic3":"images/project3.jpg"
      }
   }
];